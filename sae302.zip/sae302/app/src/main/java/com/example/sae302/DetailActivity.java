package com.example.sae302;

import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * DetailActivity:
 * - Récupère l'ID passé par l'intent (vuln_id)
 * - Appelle l'API: /api/failles/id.php?id=XX
 * - Affiche les champs + la sortie brute (details)
 */
public class DetailActivity extends AppCompatActivity {

    // Emulator -> PC host mapping (si ton serveur est accessible via 8080 sur ton PC)
    // Si tu utilises une IP LAN à la place, remplace 10.0.2.2 par l'IP du serveur.
    private static final String API_BASE = "http://10.0.2.2:8080/api/failles";

    private TextView tvTitle, tvMeta, tvDesc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        tvTitle = findViewById(R.id.tvTitle);
        tvMeta  = findViewById(R.id.tvMeta);
        tvDesc  = findViewById(R.id.tvDesc);

        int vulnId = getIntent().getIntExtra("vuln_id", -1);
        if (vulnId == -1) {
            Toast.makeText(this, "ID de faille invalide", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        new FetchDetailTask().execute(API_BASE + "/id.php?id=" + vulnId);
    }

    private class FetchDetailTask extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... urls) {
            StringBuilder result = new StringBuilder();

            try {
                URL url = new URL(urls[0]);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(8000);
                conn.setReadTimeout(15000);

                BufferedReader reader =
                        new BufferedReader(new InputStreamReader(conn.getInputStream()));

                String line;
                while ((line = reader.readLine()) != null) {
                    result.append(line);
                }
                reader.close();

                return result.toString();

            } catch (Exception e) {
                return "ERROR: " + e.getMessage();
            }
        }

        @Override
        protected void onPostExecute(String response) {
            if (response.startsWith("ERROR")) {
                Toast.makeText(DetailActivity.this, response, Toast.LENGTH_LONG).show();
                return;
            }

            try {
                // id.php doit renvoyer un OBJET JSON
                JSONObject o = new JSONObject(response);

                // Champs possibles venant de ta DB / API (avec alias)
                // Exemple id.php conseillé:
                // target AS ip, title AS type, severity AS risque, description, details, source_tool, created_at
                String id = o.optString("id", "-");
                String ip = o.optString("ip", o.optString("target", "-"));
                String type = o.optString("type", o.optString("title", "-"));
                String risque = o.optString("risque", o.optString("severity", "-"));

                // Si ton API renvoie source_tool et created_at (recommandé)
                String tool = o.optString("source_tool", o.optString("tool", "-"));
                String createdAt = o.optString("created_at", "-");

                String description = o.optString("description", "(pas de description)");
                String details = o.optString("details", "");

                // Affiche le titre
                tvTitle.setText(type);

                // Affiche infos rapides (meta)
                // Tu peux enlever tool/createdAt si ton API ne les renvoie pas
                String meta = "ID: #" + id +
                        "\nIP: " + ip +
                        "\nRisque: " + risque +
                        "\nOutil: " + tool +
                        "\nDate: " + createdAt;

                tvMeta.setText(meta);

                // Affiche description + sortie brute
                if (details != null && !details.trim().isEmpty()) {
                    tvDesc.setText(description + "\n\n--- Sortie outil (raw) ---\n" + details);
                } else {
                    tvDesc.setText(description + "\n\n(Aucun champ 'details' renvoyé par l'API)");
                }

            } catch (Exception e) {
                Toast.makeText(DetailActivity.this, "Parse error: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
    }
}
